package com.example.a01282627_imagen_web;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.appcompat.app.AppCompatActivity;
//import android.support.v4.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import java.util.Random;
import static java.lang.Math.random;
import static java.security.AccessController.getContext;

//import java.lang.annotation.Target;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    final String BASE_URL = "http://www.floraphotographs.com/showrandomios.php?color=";

    final int CANTIDAD_COLORES = 5;
    final String IMAGEN_BITMAP = "bitmap_flor";

    private Button btnLoad;
    private ImageView ivFlor;
    String[] coloresArray;
    String florURL;
    Bitmap florBitmap;

    private Target target = new Target() {

        @Override
        public void onBitmapLoaded (Bitmap bitmap, Picasso.LoadedFrom from) {

            ivFlor.setImageBitmap(bitmap);
            florBitmap = bitmap;
        }

        @Override
        public void onBitmapFailed (Exception e, Drawable errorDrawable) {

        }

        @Override
        public void onPrepareLoad (Drawable placeHolderDrawable) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        coloresArray = getResources().getStringArray(R.array.nombre_color);

        ivFlor = (ImageView) findViewById(R.id.imagen_flor);
        btnLoad = (Button) findViewById(R.id.button_load);

        btnLoad.setOnClickListener (this);

    }

    @Override
    public void onClick (View v) {

        Random r = new Random();
        int randomColor = r.nextInt(CANTIDAD_COLORES);
        String color = coloresArray [randomColor];

        try{
            florURL = BASE_URL + color + "&session=100";

            if (isConnected()) {
                loadImagePicasso_2(florURL);
            }
            else
                Toast.makeText(getApplicationContext(), "No internet connection", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Toast.makeText(getApplicationContext(), color, Toast.LENGTH_SHORT).show();
    }

    void loadImagePicasso_2 (String florURL) {
        Picasso.get().
                load(florURL).
                error (R.mipmap.ic_launcher).
                into(target);
    }

    public boolean isConnected() {

        ConnectivityManager cm = (ConnectivityManager)
                this.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (null != cm) {
            NetworkInfo info = cm.getActiveNetworkInfo();
            return (info != null && info.isConnected());
        }

        return false;
    }

    @Override
    public void onSaveInstanceState (Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putParcelable(IMAGEN_BITMAP, florBitmap);
    }

    @Override
    protected void onRestoreInstanceState (Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        florBitmap = savedInstanceState.getParcelable(IMAGEN_BITMAP);
        ivFlor.setImageBitmap(florBitmap);
    }
}
